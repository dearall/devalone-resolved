# Changelog

## Release 1.1.0

**Features**

Config linux dns client.

**Bugfixes**

**Known Issues**
