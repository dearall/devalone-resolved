# Changelog

## Release 1.1.4

**Features**

Config linux dns client.

**Bugfixes**

**Known Issues**
